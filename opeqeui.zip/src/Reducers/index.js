import { combineReducers } from "redux";
import { food } from "./food";

export const reducers = combineReducers({
    food
})